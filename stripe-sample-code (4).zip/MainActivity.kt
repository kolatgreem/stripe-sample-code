package com.stripe.example

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.stripe.stripeterminal.Terminal
import com.stripe.stripeterminal.external.callable.*
import com.stripe.stripeterminal.external.models.DiscoveryConfiguration
import com.stripe.stripeterminal.log.LogLevel
import com.stripe.stripeterminal.external.models.*
import retrofit2.Call
import retrofit2.Response
import java.lang.ref.WeakReference

class MainActivity : AppCompatActivity() {

    // Register the permissions callback to handles the response to the system permissions dialog.
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
        ::onPermissionResult
    )

    companion object {
        // The code that denotes the request for location permissions
        private const val REQUEST_CODE_LOCATION = 1


        private val discoveryConfig =
            DiscoveryConfiguration(0, DiscoveryMethod.INTERNET, true)
        /*** Payment processing callbacks ***/

        // (Step 1 found below in the startPayment function)
        // Step 2 - once we've created the payment intent, it's time to read the card
        private val createPaymentIntentCallback by lazy {
            object : PaymentIntentCallback {
                override fun onSuccess(paymentIntent: PaymentIntent) {
                    Terminal.getInstance()
                        .collectPaymentMethod(paymentIntent, collectPaymentMethodCallback)
                }

                override fun onFailure(e: TerminalException) {
                    // Update UI w/ failure
                }
            }
        }

        // Step 3 - we've collected the payment method, so it's time to process the payment
        private val collectPaymentMethodCallback by lazy {
            object : PaymentIntentCallback {
                override fun onSuccess(paymentIntent: PaymentIntent) {
                    Terminal.getInstance().processPayment(paymentIntent, processPaymentCallback)
                }

                override fun onFailure(e: TerminalException) {
                    // Update UI w/ failure
                }
            }
        }

        // Step 4 - we've processed the payment! Show a success screen
        private val processPaymentCallback by lazy {
            object : PaymentIntentCallback {
                override fun onSuccess(paymentIntent: PaymentIntent) {
                    ApiClient.capturePaymentIntent(paymentIntent.id)
                }

                override fun onFailure(e: TerminalException) {
                    // Update UI w/ failure
                }
            }
        }
    }

    private val readerClickListener = ReaderClickListener(WeakReference(this))
    private val readerAdapter = ReaderAdapter(readerClickListener)

    /**
     * Upon starting, we should verify we have the permissions we need, then start the app
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        if (BluetoothAdapter.getDefaultAdapter()?.isEnabled == false) {
            BluetoothAdapter.getDefaultAdapter().enable()
        }

        findViewById<RecyclerView>(R.id.reader_recycler_view).apply {
            adapter = readerAdapter
        }

        findViewById<View>(R.id.discover_button).setOnClickListener {
            discoverReaders()
        }

        findViewById<View>(R.id.collect_payment_button).setOnClickListener {
            startPayment()
        }
    }

    override fun onResume() {
        super.onResume()
        requestPermissionsIfNecessary()
    }

    private fun isGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissionsIfNecessary() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissionsIfNecessarySdk31()
        } else {
            requestPermissionsIfNecessarySdkBelow31()
        }
    }

    private fun requestPermissionsIfNecessarySdkBelow31() {
        // Check for location permissions
        if (!isGranted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            // If we don't have them yet, request them before doing anything else
            requestPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
        } else if (!Terminal.isInitialized() && verifyGpsEnabled()) {
            initialize()
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun requestPermissionsIfNecessarySdk31() {
        // Check for location and bluetooth permissions
        val deniedPermissions = mutableListOf<String>().apply {
            if (!isGranted(Manifest.permission.ACCESS_FINE_LOCATION)) add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (!isGranted(Manifest.permission.BLUETOOTH_CONNECT)) add(Manifest.permission.BLUETOOTH_CONNECT)
            if (!isGranted(Manifest.permission.BLUETOOTH_SCAN)) add(Manifest.permission.BLUETOOTH_SCAN)
        }.toTypedArray()

        if (deniedPermissions.isNotEmpty()) {
            // If we don't have them yet, request them before doing anything else
            requestPermissionLauncher.launch(deniedPermissions)
        } else if (!Terminal.isInitialized() && verifyGpsEnabled()) {
            initialize()
        }
    }

    /**
     * Receive the result of our permissions check, and initialize if we can
     */
    private fun onPermissionResult(result: Map<String, Boolean>) {
        val deniedPermissions: List<String> = result
            .filter { !it.value }
            .map { it.key }

        // If we receive a response to our permission check, initialize
        if (deniedPermissions.isEmpty() && !Terminal.isInitialized() && verifyGpsEnabled()) {
            initialize()
        }
    }

    fun updateReaderConnection(isConnected: Boolean) {
        val recyclerView = findViewById<RecyclerView>(R.id.reader_recycler_view)
        findViewById<View>(R.id.collect_payment_button).visibility =
            if (isConnected) View.VISIBLE else View.INVISIBLE
        findViewById<View>(R.id.discover_button).visibility =
            if (isConnected) View.INVISIBLE else View.VISIBLE
        recyclerView.visibility = if (isConnected) View.INVISIBLE else View.VISIBLE

        if (!isConnected) {
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = readerAdapter
        }
    }

    private fun initialize() {
        // Initialize the Terminal as soon as possible
        try {
            Terminal.initTerminal(
                applicationContext, LogLevel.VERBOSE, TokenProvider(), TerminalEventListener()
            )
        } catch (e: TerminalException) {
            throw RuntimeException(
                "Location services are required in order to initialize " +
                        "the Terminal.",
                e
            )
        }

        val isConnectedToReader = Terminal.getInstance().connectedReader != null
        updateReaderConnection(isConnectedToReader)
    }

    private fun discoverReaders() {
        val discoveryCallback = object : Callback {
            override fun onSuccess() {
                // Update your UI
            }

            override fun onFailure(e: TerminalException) {
                // Update your UI
            }
        }

        val discoveryListener = object : DiscoveryListener {
            override fun onUpdateDiscoveredReaders(readers: List<Reader>) {
                runOnUiThread {
                    readerAdapter.updateReaders(readers)
                }
            }
        }

        Terminal.getInstance().discoverReaders(discoveryConfig, discoveryListener, discoveryCallback)
    }

    private fun startPayment() {
        // Step 1: create payment intent
        // we'll need to create it on the server and then fetch it
        try {
            ApiClient.createPaymentIntent(500, "usd", object : retrofit2.Callback<ServerPaymentIntent> {
                override fun onResponse(
                    call: Call<ServerPaymentIntent>,
                    response: Response<ServerPaymentIntent>
                ) {
                    Terminal.getInstance().retrievePaymentIntent(response.body()!!.secret, createPaymentIntentCallback)
                }

                override fun onFailure(call: Call<ServerPaymentIntent>, t: Throwable) {
                    // handle exception
                }
            })
        } catch (e: Exception) {
            // handle exception
        }
    }

    private fun verifyGpsEnabled(): Boolean {
        val locationManager: LocationManager? =
            applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager?
        var gpsEnabled = false

        try {
            gpsEnabled = locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) ?: false
        } catch (exception: Exception) {}

        if (!gpsEnabled) {
            // notify user
            AlertDialog.Builder(ContextThemeWrapper(this, R.style.Theme_MaterialComponents_DayNight_DarkActionBar))
                .setMessage("Please enable location services")
                .setCancelable(false)
                .setPositiveButton("Open location settings") { param, paramInt ->
                    this.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .create()
                .show()
        }

        return gpsEnabled
    }
}