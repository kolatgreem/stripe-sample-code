package com.stripe.example

data class ServerPaymentIntent(val intent: String, val secret: String)