package main

import (
  "bytes"
  "encoding/json"
  "io"
  "log"
  "net/http"
  "strconv"

  "github.com/stripe/stripe-go"
  "github.com/stripe/stripe-go/paymentintent"
  "github.com/stripe/stripe-go/terminal/connectiontoken"
  "github.com/stripe/stripe-go/terminal/location"
)

func main() {
  // This is your test secret API key.
  stripe.Key = "sk_test_51LiZTSLBV1ouchSWr6eXS0QYeJVKqwlTO5jGiM70wxECS4xau55ZoU0AIT5VVPCxhyywF6BHS0nDLdmxq4ND78kx00KjLIowYH"

  fs := http.FileServer(http.Dir("public"))
  http.Handle("/", fs)
  http.HandleFunc("/connection_token", handleConnectionToken)
  http.HandleFunc("/create_payment_intent", handleCreate)
  http.HandleFunc("/capture_payment_intent", handleCapture)

  addr := "localhost:4242"
  log.Printf("Listening on %s ...", addr)
  log.Fatal(http.ListenAndServe(addr, nil))
}

func createLocation(w http.ResponseWriter, r *http.Request) *stripe.TerminalLocation {
  params := &stripe.TerminalLocationParams{
    Address: &stripe.AccountAddressParams{
      Line1: stripe.String("1272 Valencia Street"),
      City: stripe.String("San Francisco"),
      State: stripe.String("CA"),
      Country: stripe.String("US"),
      PostalCode: stripe.String("94110"),
    },
    DisplayName: stripe.String("HQ"),
  }

  l, _ := location.New(params)

  return l
}



// The ConnectionToken's secret lets you connect to any Stripe Terminal reader
// and take payments with your Stripe account.
// Be sure to authenticate the endpoint for creating connection tokens.
func handleConnectionToken(w http.ResponseWriter, r *http.Request) {
  if r.Method != "POST" {
    http.Error(w, http.StatusText(http.StatusMethodNotAllowed), http.StatusMethodNotAllowed)
    return
  }

  params := &stripe.TerminalConnectionTokenParams{}
  ct, err := connectiontoken.New(params)

  if err != nil {
    http.Error(w, err.Error(), http.StatusInternalServerError)
    log.Printf("pi.New: %v", err)
    return
  }

  writeJSON(w, struct {
    Secret string `json:"secret"`
  }{
    Secret: ct.Secret,
  })
}

func handleCreate(w http.ResponseWriter, r *http.Request) {
  if r.Method != "POST" {
    http.Error(w, http.StatusText(http.StatusMethodNotAllowed), http.StatusMethodNotAllowed)
    return
  }

  var req struct {
    PaymentIntentAmount string `json:"amount"`
  }

  if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
    http.Error(w, err.Error(), http.StatusInternalServerError)
    log.Printf("json.NewDecoder.Decode: %v", err)
    return
  }

  amount, _ := strconv.ParseInt(req.PaymentIntentAmount, 10, 64)

  // For Terminal payments, the 'payment_method_types' parameter must include
  // 'card_present'.
  // To automatically capture funds when a charge is authorized,
  // set `capture_method` to `automatic`.
  params := &stripe.PaymentIntentParams{
    Amount: stripe.Int64(amount),
    Currency: stripe.String(string(stripe.CurrencyUSD)),
    PaymentMethodTypes: stripe.StringSlice([]string{
      "card_present",
    }),
    CaptureMethod: stripe.String("manual"),
  }
  pi, err := paymentintent.New(params)

  if err != nil {
    http.Error(w, err.Error(), http.StatusInternalServerError)
    log.Printf("pi.New: %v", err)
    return
  }

  writeJSON(w, pi)
}



func handleCapture(w http.ResponseWriter, r *http.Request) {
  if r.Method != "POST" {
    http.Error(w, http.StatusText(http.StatusMethodNotAllowed), http.StatusMethodNotAllowed)
    return
  }

  var req struct {
    PaymentIntentID string `json:"payment_intent_id"`
  }

  if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
    http.Error(w, err.Error(), http.StatusInternalServerError)
    log.Printf("json.NewDecoder.Decode: %v", err)
    return
  }

  pi, err := paymentintent.Capture(req.PaymentIntentID, nil)

  if err != nil {
    http.Error(w, err.Error(), http.StatusInternalServerError)
    log.Printf("pi.Capture: %v", err)
    return
  }

  writeJSON(w, pi)
}

func writeJSON(w http.ResponseWriter, v interface{}) {
  var buf bytes.Buffer
  if err := json.NewEncoder(&buf).Encode(v); err != nil {
    http.Error(w, err.Error(), http.StatusInternalServerError)
    log.Printf("json.NewEncoder.Encode: %v", err)
    return
  }
  w.Header().Set("Content-Type", "application/json")
  if _, err := io.Copy(w, &buf); err != nil {
    log.Printf("io.Copy: %v", err)
    return
  }
}